<?php
class session
{
	public $user_id;
	public $user_name;
	public $user_type;
	public $error = array();
	
	public function __construct()
	{
		session_start();
	}
}

?>