<!DOCTYPE html>
<html lang="zxx" dir="ltr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
	<title><?php print ($companyshortname . $pagetitle); ?></title>
    <meta name="description" content="<?php echo $pagedescr; ?>">
	<meta name="keywords" content="<?php echo $pagekeywords; ?>">
	
    <!-- Responsive Settings -->
    <meta name="theme-color" content="#f2f3f5" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- FAVICON STARTS -->
	<link rel="apple-touch-icon" sizes="57x57" href="assets/site/favicon/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="assets/site/favicon/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="assets/site/favicon/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="assets/site/favicon/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="assets/site/favicon/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="assets/site/favicon/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="assets/site/favicon/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="assets/site/favicon/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="assets/site/favicon/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192"  href="assets/site/favicon/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/site/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/site/favicon/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/site/favicon/favicon-16x16.png">
	<link rel="manifest" href="assets/site/favicon/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="assets/site/favicon/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<!-- FAVICON ENDS -->
	
	<link rel="preload" href="assets/site/js/vendors/uikit.min.js" as="script">
    <link rel="preload" href="assets/site/css/vendors/uikit.min.css" as="style">
    <link rel="preload" href="assets/site/css/style.css" as="style">
    <!-- Icon preload -->
    <link rel="preload" href="assets/site/fonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="assets/site/fonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin>
    <!-- Font preload -->
    <link rel="preload" href="assets/site/fonts/inter-v2-latin-regular.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="assets/site/fonts/inter-v2-latin-500.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="assets/site/fonts/inter-v2-latin-700.woff2" as="font" type="font/woff2" crossorigin>
    
    <!-- CSS -->
    <link rel="stylesheet" href="assets/site/css/vendors/uikit.min.css">
    <link rel="stylesheet" href="assets/site/css/style.css">
    <link rel="stylesheet" href="assets/site/css/pricing-table.css">
    <link rel="stylesheet" href="assets/site/css/responsive-table.css">
    <link rel="stylesheet" href="assets/site/css/raffle-draw.css">
	<!--Start of Pinterest Tracking Script-->
	
	<!--End of Pinterest Tracking Script-->	
	<!--Start of Zopim Live Chat Script-->
	
	<!--End of Zopim Live Chat Script-->
	<script src="//code.tidio.co/fpzwuc33k314xqao9iqo0wgtdwtzclkz.js" async></script>
	<!-- Google Analytics Code Starts -->
	
	<!-- Google Analytics Code Ends -->