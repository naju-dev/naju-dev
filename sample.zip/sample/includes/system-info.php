<?php

/*Customer Company (Head Office) Information*/
$companyshortname='STX Brokers';
$companyname='STX Brokers (Pte) Ltd';

$companyaddress='24th Floor, 20 Fenchurch St, London EC3M 3BY, UK.';
$companyaddressfull='24th Floor, 20 Fenchurch St, London EC3M 3BY, United Kingdom.';

$companytele='+44 (20) 8089 7206';
$hrefcompanytele='+442080897206';

$companyweb='https://stxbrokers.com';
$companydomain='stxbrokers.com';
$companyemail='hello@stxbrokers.com';
$companysupportemail='support@stxbrokers.com';
$companyaccountsemail='accounts@stxbrokers.com';
?>