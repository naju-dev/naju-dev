		<div class="uk-section uk-section-secondary in-footer-feature uk-margin-medium-top">
            <div class="uk-container">
                <div class="uk-grid uk-flex uk-flex-center">
                    <div class="uk-width-5-6@m">
                        <div class="uk-grid uk-child-width-1-4@s" data-uk-grid>
                            <div class="uk-flex uk-flex-middle">
                                <div class="uk-margin-right">
                                    <i class="fas fa-users in-icon-wrap"></i>
                                </div>
                                <div>
                                    <h6 class="uk-margin-remove">+8M Total Users</h6>
                                </div>
                            </div>
                            <div class="uk-flex uk-flex-middle">
                                <div class="uk-margin-right">
                                    <i class="fas fa-map in-icon-wrap"></i>
                                </div>
                                <div>
                                    <h6 class="uk-margin-remove">+100 Countries</h6>
                                </div>
                            </div>
                            <div class="uk-flex uk-flex-middle uk-flex-center@m">
                                <div class="uk-margin-right">
                                    <i class="fas fa-building in-icon-wrap"></i>
                                </div>
                                <div>
                                    <h6 class="uk-margin-remove">+35K Transactions</h6>
                                </div>
                            </div>
                            <div class="uk-flex uk-flex-middle uk-flex-right@m">
                                <div class="uk-margin-right">
                                    <i class="fas fa-globe in-icon-wrap"></i>
                                </div>
                                <div>
                                    <h6 class="uk-margin-remove">+15 Languages</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>