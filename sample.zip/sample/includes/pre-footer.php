				<div class="uk-child-width-1-2@m" data-uk-grid>
                    <div class="in-footer-logo">
                        <img src="assets/site/img/in-lazy.gif" data-src="assets/site/img/stxbrokers_logo.png" alt="logo" width="157" height="57" data-uk-img>
                    </div>
                </div>
                <div class="uk-child-width-1-2@s uk-child-width-1-4@m uk-margin-large-top" data-uk-grid>
                    <div>
                        <h5>Company</h5>
                        <ul class="uk-list uk-link-text">
                            <li><a href="about-us">About <?php echo $companyshortname; ?></a></li>
							<li><a href="testimonials">Testimonials</a></li>
                            <li><a href="contact">Contact</a></li>
                            <li><a href="our-services">Our Services</a></li>
                        </ul>
                    </div>
                    <div>
                        <h5>Apps &amp; Accounts</h5>
                        <ul class="uk-list uk-link-text">
                            <li><a href="metatrader">MetaTrader</a></li>
							<li><a href="mobile-trading-apps">Mobile Trading Apps</a></li>
							<li><a href="webtrader">Webtrader</a></li>
                            <li><a href="account-types">Account Types</a></li>
                        </ul>
                    </div>
                    <div>
                        <h5>Legal Information</h5>
                        <ul class="uk-list uk-link-text">
                            <li><a href="risk-disclosure-statement">Risk Disclosure Statement</a></li>
							<li><a href="terms-conditions">Terms & Conditions</a></li>
							<li><a href="cookie-policy">Cookie Policy</a></li>
							<li><a href="privacy-policy">Privacy Policy</a></li>
                        </ul>
                    </div>
                    <div>
                        <h5>Support &amp; Portal</h5>
                        <ul class="uk-list uk-link-text">
                            <li><a href="contact">Contact Center</a></li>
                            <li><a href="faqs">Frequently Asked Questions</a></li>
                            <li><a href="https://stxbrokers.4xp.tech/" target="_blank">Login to Portal</a></li>
                            <li><a href="https://stxbrokers.4xp.tech/" target="_blank">Create Account</a></li>
                        </ul>
                    </div>
                </div>