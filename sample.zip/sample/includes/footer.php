			<!-- Footer Bottom -->
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="inner clearfix">
                        <div class="copyright">.</div>
                    </div>
                </div>
				<div style="text-align: justify; font-size: 11px; margin-left: 60px; margin-right: 60px; line-height: normal;">
					
				</div>
            </div>
			<div class="uk-grid uk-margin-large-top">
                    <div class="uk-width-1-1">
					<p class="uk-heading-line uk-margin-large-bottom"><span>&copy; <?php echo date('Y');?> All Rights Reserved to <a href="<?php echo $companyweb; ?>"><?php echo $companyname;?></a></span></p>
					
					<p class="in-trading-risk"><b><u><?php echo $companydomain; ?> helps traders of all levels learn how to trade the financial markets.</u></b></p>

					<p class="in-trading-risk">The information on the <?php echo $companydomain; ?> website and inside our Trading Room platform is intended for educational purposes and is not to be construed as investment advice. Trading the financial markets carries a high level of risk and may not be suitable for all investors. Before trading, you should carefully consider your investment objectives, experience, and risk appetite. Only trade with money you are prepared to lose. Like any investment, there is a possibility that you could sustain losses of some or all of your investment whilst trading. You should seek independent advice before trading if you have any doubts. Past performance in the markets is not a reliable indicator of future performance.</p>

					<p class="in-trading-risk"><?php echo $companydomain; ?> takes no responsibility for loss incurred as a result of the content provided inside our Trading Room. By signing up as a member you acknowledge that we are not providing financial advice and that you are making the decision on the trades you place in the markets. We have no knowledge of the level of money you are trading with or the level of risk you are taking with each trade.</p>

					<p class="in-trading-risk"><b>Warning:</b> Our team of mentors will never contact you directly outside of the Trading Room. If any person(s) contacts you via Social Media platforms offering account management or asking for payment, this is not Forex Signals and our mentors. It has been brought to our attention that a number of people are posing as our mentors. Please report these Social Media pages and do not enter into any arrangement with them - this is not Forex Signals.</p>

					<p class="in-trading-risk">The <?php echo $companydomain; ?> website uses cookies in order to provide you with the best experience. By visiting our website with your browser set to allow cookies, or by accepting our <a href="cookie-policy">Cookie Policy</a> notification you consent to our <a href="privacy-policy">Privacy Policy</a>, which details our <a href="cookie-policy">Cookie Policy</a>.</p>
                    </div>
                </div>
					
			