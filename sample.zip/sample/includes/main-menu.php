			<div class="uk-section uk-padding-remove-vertical in-header-inner uk-background-cover uk-background-top-center" style="background-image: url(assets/site/img/in-liquid-slide-bg.png);">
            <nav class="uk-navbar-container" data-uk-sticky="show-on-up: true; animation: uk-animation-slide-top;">
                <div class="uk-container" data-uk-navbar>
                    <div class="uk-navbar-left">
                        <div class="uk-navbar-item">
                            <!-- logo begin -->
                            <a class="uk-logo" href="./">
                                <img src="assets/site/img/in-lazy.gif" data-src="assets/site/img/stxbrokers_logo.png" alt="logo" width="160" height="34" data-uk-img>
                            </a>
                            <!-- logo end -->
                            <!-- navigation begin -->
                            <ul class="uk-navbar-nav uk-visible@m">
                                <li><a href="#">Accounts<i class="fas fa-chevron-down"></i></a>
                                    <div class="uk-navbar-dropdown">
                                        <ul class="uk-nav uk-navbar-dropdown-nav">
                                            <li><a href="account-types">Account Types</a></li>
                                            <li><a href="promotions">Promotions</a></li>
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="our-services">Our Services</a></li>
                                <li><a href="#">Legal Information<i class="fas fa-chevron-down"></i></a>
                                    <div class="uk-navbar-dropdown">
                                        <ul class="uk-nav uk-navbar-dropdown-nav">
                                            <li><a href="risk-disclosure-statement">Risk Disclosure Statement</a></li>
                                            <li><a href="terms-conditions">Terms & Conditions</a></li>
                                            <li><a href="cookie-policy">Cookie Policy</a></li>
                                            <li><a href="privacy-policy">Privacy Policy</a></li>
                                        </ul>
                                    </div>
                                </li>
								<li><a href="#">Platforms<i class="fas fa-chevron-down"></i></a>
                                    <div class="uk-navbar-dropdown">
                                        <ul class="uk-nav uk-navbar-dropdown-nav">
                                            <li><a href="metatrader">MetaTrader</a></li>
                                            <li><a href="mobile-trading-apps">Mobile Trading Apps</a></li>
                                            <li><a href="webtrader">Webtrader</a></li>
                                        </ul>
                                    </div>
                                </li>
								<li><a href="#">Company<i class="fas fa-chevron-down"></i></a>
                                    <div class="uk-navbar-dropdown">
                                        <ul class="uk-nav uk-navbar-dropdown-nav">
                                            <li><a href="about-us">About Us</a></li>
                                            <li><a href="testimonials">Testimonials</a></li>
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="contact">Contact</a></li>
                            </ul>
                            <!-- navigation end -->
                        </div>
                    </div>
                    <div class="uk-navbar-right">
                        <div class="uk-navbar-item uk-visible@m in-optional-nav">
                            <a href="https://stxbrokers.4xp.tech/" target="_blank" class="uk-button uk-button-primary uk-border-rounded"><font color="white">Sign In / Sign Up</font></a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>