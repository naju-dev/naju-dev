<?php
include('library/config.php');

include(TEMPLATE.'_site.php');
?>