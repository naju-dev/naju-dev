<?php
$pagetitle = ' - Know More About Our Company';

$pagedescr = 'STX is one of the finest and the most secure trading company found by financial experts and professionals with years of experience.';

$pagekeywords = '';

$pageid = 'home';

include(INC_PATH . "system-info.php");

include(INC_PATH . "header.php");
?>

<body>
<!-- preloader begin -->
<div class="in-loader">
    <div></div>
    <div></div>
    <div></div>
</div>
<!-- preloader end -->
<header>
    <!-- header content begin -->

    <!-- Starting Code of Main Menu -->
    <?php include("includes/main-menu.php"); ?>
    <!-- Ending Code of Main Menu -->

    <!-- header content end -->
</header>
<!-- breadcrumb content begin -->
<div class="uk-section uk-padding-remove-vertical in-liquid-breadcrumb">
    <div class="uk-container">
        <div class="uk-grid">
            <div class="uk-width-1-1">
                <ul class="uk-breadcrumb"></ul>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb content end -->
<main>
    <!-- section content begin -->
    <div class="uk-section">
        <div class="uk-container">
            <div class="uk-grid">
                <div class="uk-width-1-1 uk-flex uk-flex-center">
                    <div class="uk-width-3-4@m uk-text-center">
                        <h2 class="uk-margin-small-bottom">We are <span
                                    class="in-highlight"><?php echo $companyshortname; ?>.</span></h2>
                        <p class="uk-text-lead uk-text-muted uk-margin-remove"><?php echo $companyshortname; ?> is one
                            of the finest and the most secure trading company found by financial experts and
                            professionals with years of experience in financial trading and online
                            technology. <?php echo $companyshortname; ?> is completely based on clients’ satisfaction
                            and focus to lead the field of <?php echo $companyshortname; ?> with innovation and
                            financial security. Trading conditions at <?php echo $companyshortname; ?> are very
                            competitive including tight spreads and recommended leverage. The transparency of financial
                            standards upheld by <?php echo $companyshortname; ?> means that traders know what they see
                            and what they get. At <?php echo $companyshortname; ?> traders are prepared to seize daily
                            opportunities and customers can trade with confidence, knowing that their trades are
                            informed by the most updated information. The advanced market tools and charts let traders
                            understand the market accurately and take perfect decisions which will let them gain what
                            they expect as traders. Since our income is based solely on the difference between Bid and
                            Ask <?php echo $companyshortname; ?> ensure trading success.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<footer>
    <!-- footer content begin -->

    <!-- Start CALL TO ACTION Section -->
    <?php include("includes/callto-action.php"); ?>
    <!-- End CALL TO ACTION Section -->

    <div class="uk-section uk-background-secondary uk-light">
        <div class="uk-container uk-text-small">

            <!-- Start PRE Footer Section -->
            <?php include("includes/pre-footer.php"); ?>
            <!-- End PRE Footer Section -->

            <!-- Start Footer Section -->
            <?php include("includes/footer.php"); ?>
            <!-- End Footer Section -->

        </div>
    </div>
    <!-- footer content end -->
    <!-- totop begin -->
    <div class="uk-visible@m">
        <a href="#" class="in-totop fas fa-chevron-up" data-uk-scroll></a>
    </div>
    <!-- totop end -->
</footer>
<!-- Javascript -->
<script src="assets/site/js/vendors/uikit.min.js"></script>
<script src="assets/site/js/vendors/blockit.min.js"></script>
<script src="assets/site/js/config-theme.js"></script>
</body>
</html>